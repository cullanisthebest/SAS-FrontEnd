define('sassample/tests/helpers/resolver', ['exports', 'ember/resolver', 'sassample/config/environment'], function (exports, _emberResolver, _sassampleConfigEnvironment) {

  var resolver = _emberResolver['default'].create();

  resolver.namespace = {
    modulePrefix: _sassampleConfigEnvironment['default'].modulePrefix,
    podModulePrefix: _sassampleConfigEnvironment['default'].podModulePrefix
  };

  exports['default'] = resolver;
});