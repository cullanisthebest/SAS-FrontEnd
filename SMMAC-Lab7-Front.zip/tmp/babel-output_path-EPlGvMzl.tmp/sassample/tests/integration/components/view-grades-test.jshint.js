define('sassample/tests/integration/components/view-grades-test.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - integration/components/view-grades-test.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'integration/components/view-grades-test.js should pass jshint.');
  });
});