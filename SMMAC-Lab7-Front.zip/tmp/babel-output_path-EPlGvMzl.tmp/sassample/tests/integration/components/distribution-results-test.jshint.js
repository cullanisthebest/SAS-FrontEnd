define('sassample/tests/integration/components/distribution-results-test.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - integration/components/distribution-results-test.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'integration/components/distribution-results-test.js should pass jshint.');
  });
});