define('sassample/tests/integration/components/manage-admissionrule-test.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - integration/components/manage-admissionrule-test.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'integration/components/manage-admissionrule-test.js should pass jshint.');
  });
});