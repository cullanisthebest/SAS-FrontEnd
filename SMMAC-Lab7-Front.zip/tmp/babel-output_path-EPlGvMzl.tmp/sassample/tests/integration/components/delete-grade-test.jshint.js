define('sassample/tests/integration/components/delete-grade-test.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - integration/components/delete-grade-test.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'integration/components/delete-grade-test.js should pass jshint.');
  });
});