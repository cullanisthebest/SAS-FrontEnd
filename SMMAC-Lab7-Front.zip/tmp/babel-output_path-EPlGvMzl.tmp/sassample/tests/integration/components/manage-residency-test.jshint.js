define('sassample/tests/integration/components/manage-residency-test.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - integration/components/manage-residency-test.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'integration/components/manage-residency-test.js should pass jshint.');
  });
});