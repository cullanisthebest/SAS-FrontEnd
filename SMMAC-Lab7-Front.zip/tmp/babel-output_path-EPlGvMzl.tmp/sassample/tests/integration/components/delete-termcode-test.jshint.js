define('sassample/tests/integration/components/delete-termcode-test.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - integration/components/delete-termcode-test.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'integration/components/delete-termcode-test.js should pass jshint.');
  });
});