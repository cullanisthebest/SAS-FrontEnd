define('sassample/tests/integration/components/manage-commentcode-test.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - integration/components/manage-commentcode-test.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'integration/components/manage-commentcode-test.js should pass jshint.');
  });
});