define('sassample/tests/integration/components/display-manage-test.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - integration/components/display-manage-test.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'integration/components/display-manage-test.js should pass jshint.');
  });
});