define('sassample/tests/integration/components/delete-city-test.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - integration/components/delete-city-test.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'integration/components/delete-city-test.js should pass jshint.');
  });
});