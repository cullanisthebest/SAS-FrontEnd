define('sassample/tests/integration/components/delete-coursecode-test.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - integration/components/delete-coursecode-test.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'integration/components/delete-coursecode-test.js should pass jshint.');
  });
});