define('sassample/tests/integration/components/manage-gender-test.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - integration/components/manage-gender-test.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'integration/components/manage-gender-test.js should pass jshint.');
  });
});