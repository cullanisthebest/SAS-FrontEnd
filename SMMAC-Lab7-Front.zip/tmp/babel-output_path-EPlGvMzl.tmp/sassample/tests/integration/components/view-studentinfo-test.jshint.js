define('sassample/tests/integration/components/view-studentinfo-test.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - integration/components/view-studentinfo-test.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'integration/components/view-studentinfo-test.js should pass jshint.');
  });
});