define('sassample/tests/integration/components/delete-residency-test.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - integration/components/delete-residency-test.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'integration/components/delete-residency-test.js should pass jshint.');
  });
});