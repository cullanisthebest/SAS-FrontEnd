define('sassample/tests/unit/models/admissionrule-test.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - unit/models/admissionrule-test.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/models/admissionrule-test.js should pass jshint.');
  });
});