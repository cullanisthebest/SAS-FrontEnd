define('sassample/tests/unit/models/commentcode-test.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - unit/models/commentcode-test.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/models/commentcode-test.js should pass jshint.');
  });
});