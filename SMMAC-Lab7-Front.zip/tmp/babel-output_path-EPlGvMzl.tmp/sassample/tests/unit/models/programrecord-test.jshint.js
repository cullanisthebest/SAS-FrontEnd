define('sassample/tests/unit/models/programrecord-test.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - unit/models/programrecord-test.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/models/programrecord-test.js should pass jshint.');
  });
});