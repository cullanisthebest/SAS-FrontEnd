define('sassample/tests/unit/models/coursecode-test.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - unit/models/coursecode-test.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/models/coursecode-test.js should pass jshint.');
  });
});