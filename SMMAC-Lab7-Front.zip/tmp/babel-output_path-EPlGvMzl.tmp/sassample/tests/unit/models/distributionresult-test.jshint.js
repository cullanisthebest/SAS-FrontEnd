define('sassample/tests/unit/models/distributionresult-test.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - unit/models/distributionresult-test.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/models/distributionresult-test.js should pass jshint.');
  });
});