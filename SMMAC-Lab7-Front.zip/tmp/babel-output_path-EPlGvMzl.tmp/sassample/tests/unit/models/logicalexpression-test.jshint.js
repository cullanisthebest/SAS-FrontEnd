define('sassample/tests/unit/models/logicalexpression-test.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - unit/models/logicalexpression-test.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/models/logicalexpression-test.js should pass jshint.');
  });
});