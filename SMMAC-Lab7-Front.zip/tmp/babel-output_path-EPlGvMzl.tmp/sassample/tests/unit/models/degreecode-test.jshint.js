define('sassample/tests/unit/models/degreecode-test.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - unit/models/degreecode-test.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/models/degreecode-test.js should pass jshint.');
  });
});