define('sassample/tests/unit/models/itrprogram-test.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - unit/models/itrprogram-test.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/models/itrprogram-test.js should pass jshint.');
  });
});