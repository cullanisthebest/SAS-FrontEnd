define('sassample/tests/models/country.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - models/country.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/country.js should pass jshint.');
  });
});