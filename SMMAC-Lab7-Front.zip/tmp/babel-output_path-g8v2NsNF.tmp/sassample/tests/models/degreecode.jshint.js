define('sassample/tests/models/degreecode.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - models/degreecode.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/degreecode.js should pass jshint.');
  });
});