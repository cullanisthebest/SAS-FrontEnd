define('sassample/tests/models/residency.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - models/residency.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/residency.js should pass jshint.');
  });
});