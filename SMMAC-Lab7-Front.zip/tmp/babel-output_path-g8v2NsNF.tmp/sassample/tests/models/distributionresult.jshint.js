define('sassample/tests/models/distributionresult.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - models/distributionresult.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/distributionresult.js should pass jshint.');
  });
});