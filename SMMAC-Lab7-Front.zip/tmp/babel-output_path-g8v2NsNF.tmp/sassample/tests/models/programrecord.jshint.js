define('sassample/tests/models/programrecord.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - models/programrecord.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/programrecord.js should pass jshint.');
  });
});