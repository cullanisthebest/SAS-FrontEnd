define('sassample/tests/models/academicload.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - models/academicload.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/academicload.js should pass jshint.');
  });
});