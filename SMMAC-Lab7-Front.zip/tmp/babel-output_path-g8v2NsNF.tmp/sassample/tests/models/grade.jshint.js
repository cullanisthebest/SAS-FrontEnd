define('sassample/tests/models/grade.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - models/grade.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/grade.js should pass jshint.');
  });
});