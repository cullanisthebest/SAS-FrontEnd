define('sassample/tests/models/login.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - models/login.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/login.js should pass jshint.');
  });
});