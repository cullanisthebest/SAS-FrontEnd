define('sassample/tests/models/academicprogramcode.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - models/academicprogramcode.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/academicprogramcode.js should pass jshint.');
  });
});