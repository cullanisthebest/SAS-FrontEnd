define('sassample/tests/models/root.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - models/root.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/root.js should pass jshint.');
  });
});