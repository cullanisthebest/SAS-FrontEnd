define('sassample/tests/models/role-permission.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - models/role-permission.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/role-permission.js should pass jshint.');
  });
});