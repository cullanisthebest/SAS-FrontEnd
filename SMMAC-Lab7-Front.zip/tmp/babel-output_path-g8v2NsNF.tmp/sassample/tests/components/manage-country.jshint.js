define('sassample/tests/components/manage-country.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - components/manage-country.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/manage-country.js should pass jshint.');
  });
});