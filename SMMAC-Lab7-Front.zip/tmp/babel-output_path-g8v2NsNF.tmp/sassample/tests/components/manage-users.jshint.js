define('sassample/tests/components/manage-users.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - components/manage-users.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/manage-users.js should pass jshint.');
  });
});