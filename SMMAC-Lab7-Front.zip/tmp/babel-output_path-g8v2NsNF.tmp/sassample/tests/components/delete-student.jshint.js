define('sassample/tests/components/delete-student.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - components/delete-student.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/delete-student.js should pass jshint.');
  });
});