define('sassample/tests/components/delete-coursecode.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - components/delete-coursecode.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/delete-coursecode.js should pass jshint.');
  });
});