define('sassample/tests/components/system-administration.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - components/system-administration.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/system-administration.js should pass jshint.');
  });
});