define('sassample/tests/components/manage-coursecode.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - components/manage-coursecode.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/manage-coursecode.js should pass jshint.');
  });
});