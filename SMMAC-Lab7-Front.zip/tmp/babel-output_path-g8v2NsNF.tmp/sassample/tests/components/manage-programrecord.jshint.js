define('sassample/tests/components/manage-programrecord.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - components/manage-programrecord.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/manage-programrecord.js should pass jshint.');
  });
});