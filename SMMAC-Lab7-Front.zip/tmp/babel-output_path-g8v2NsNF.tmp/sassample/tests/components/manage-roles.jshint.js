define('sassample/tests/components/manage-roles.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - components/manage-roles.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/manage-roles.js should pass jshint.');
  });
});