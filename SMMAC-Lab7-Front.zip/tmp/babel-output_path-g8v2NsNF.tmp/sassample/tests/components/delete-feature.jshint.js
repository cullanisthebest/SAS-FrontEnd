define('sassample/tests/components/delete-feature.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - components/delete-feature.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/delete-feature.js should pass jshint.');
  });
});