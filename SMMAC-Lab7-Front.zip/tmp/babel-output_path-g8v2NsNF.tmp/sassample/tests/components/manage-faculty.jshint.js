define('sassample/tests/components/manage-faculty.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - components/manage-faculty.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/manage-faculty.js should pass jshint.');
  });
});