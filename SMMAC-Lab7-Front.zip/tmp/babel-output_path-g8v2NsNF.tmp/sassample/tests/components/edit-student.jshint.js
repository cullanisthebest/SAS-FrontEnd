define('sassample/tests/components/edit-student.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - components/edit-student.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/edit-student.js should pass jshint.');
  });
});