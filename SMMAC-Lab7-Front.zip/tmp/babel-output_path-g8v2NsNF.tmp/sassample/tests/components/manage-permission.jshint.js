define('sassample/tests/components/manage-permission.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - components/manage-permission.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/manage-permission.js should pass jshint.');
  });
});