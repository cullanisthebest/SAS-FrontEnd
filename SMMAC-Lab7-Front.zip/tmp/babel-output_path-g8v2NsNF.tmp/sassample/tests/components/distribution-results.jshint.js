define('sassample/tests/components/distribution-results.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - components/distribution-results.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(false, 'components/distribution-results.js should pass jshint.\ncomponents/distribution-results.js: line 11, col 13, Duplicate key \'grades\'.\ncomponents/distribution-results.js: line 96, col 17, \'self\' is defined but never used.\ncomponents/distribution-results.js: line 98, col 17, \'gradesArray\' is defined but never used.\ncomponents/distribution-results.js: line 99, col 17, \'studentChoicesArr\' is defined but never used.\ncomponents/distribution-results.js: line 100, col 17, \'logicalExpressionArr\' is defined but never used.\n\n5 errors');
  });
});