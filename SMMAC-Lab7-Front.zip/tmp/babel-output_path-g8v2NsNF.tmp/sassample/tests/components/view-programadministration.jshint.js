define('sassample/tests/components/view-programadministration.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - components/view-programadministration.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(false, 'components/view-programadministration.js should pass jshint.\ncomponents/view-programadministration.js: line 20, col 64, Missing semicolon.\n\n1 error');
  });
});