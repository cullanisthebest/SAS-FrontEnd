define('sassample/tests/components/delete-city.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - components/delete-city.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/delete-city.js should pass jshint.');
  });
});