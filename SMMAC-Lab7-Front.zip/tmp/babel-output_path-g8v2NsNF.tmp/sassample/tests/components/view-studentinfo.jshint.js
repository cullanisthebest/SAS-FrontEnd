define('sassample/tests/components/view-studentinfo.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - components/view-studentinfo.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(false, 'components/view-studentinfo.js should pass jshint.\ncomponents/view-studentinfo.js: line 2, col 8, \'$\' is defined but never used.\n\n1 error');
  });
});