define('sassample/tests/components/delete-degreecode.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - components/delete-degreecode.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/delete-degreecode.js should pass jshint.');
  });
});