define('sassample/tests/components/manage-grade.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - components/manage-grade.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/manage-grade.js should pass jshint.');
  });
});