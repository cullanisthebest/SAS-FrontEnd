define('sassample/tests/components/edit-user-profile.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - components/edit-user-profile.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/edit-user-profile.js should pass jshint.');
  });
});