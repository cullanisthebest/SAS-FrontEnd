define('sassample/tests/components/delete-admissionrule.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - components/delete-admissionrule.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/delete-admissionrule.js should pass jshint.');
  });
});