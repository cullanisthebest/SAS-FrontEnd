define('sassample/tests/components/view-admissionrule.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - components/view-admissionrule.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/view-admissionrule.js should pass jshint.');
  });
});