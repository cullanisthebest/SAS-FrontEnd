define('sassample/tests/components/manage-degreecode.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - components/manage-degreecode.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/manage-degreecode.js should pass jshint.');
  });
});