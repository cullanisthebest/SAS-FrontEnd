define('sassample/tests/components/view-faculty.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - components/view-faculty.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/view-faculty.js should pass jshint.');
  });
});