define('sassample/tests/components/manage-features.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - components/manage-features.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/manage-features.js should pass jshint.');
  });
});