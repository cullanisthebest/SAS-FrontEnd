define('sassample/tests/components/delete-faculty.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - components/delete-faculty.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/delete-faculty.js should pass jshint.');
  });
});