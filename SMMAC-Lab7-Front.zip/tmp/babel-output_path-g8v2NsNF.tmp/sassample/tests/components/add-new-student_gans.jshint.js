define('sassample/tests/components/add-new-student_gans.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - components/add-new-student_gans.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(false, 'components/add-new-student_gans.js should pass jshint.\ncomponents/add-new-student_gans.js: line 84, col 13, \'self\' is defined but never used.\n\n1 error');
  });
});