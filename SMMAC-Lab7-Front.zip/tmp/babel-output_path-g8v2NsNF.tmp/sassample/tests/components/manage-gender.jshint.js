define('sassample/tests/components/manage-gender.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - components/manage-gender.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/manage-gender.js should pass jshint.');
  });
});