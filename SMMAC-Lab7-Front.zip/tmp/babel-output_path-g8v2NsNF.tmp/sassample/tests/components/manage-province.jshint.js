define('sassample/tests/components/manage-province.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - components/manage-province.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(true, 'components/manage-province.js should pass jshint.');
  });
});