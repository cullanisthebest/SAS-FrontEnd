define('sassample/tests/components/display-manage.jshint', ['exports'], function (exports) {
  'use strict';

  QUnit.module('JSHint - components/display-manage.js');
  QUnit.test('should pass jshint', function (assert) {
    assert.expect(1);
    assert.ok(false, 'components/display-manage.js should pass jshint.\ncomponents/display-manage.js: line 13, col 10, Duplicate key \'model\'.\ncomponents/display-manage.js: line 14, col 11, \'self\' is defined but never used.\n\n2 errors');
  });
});