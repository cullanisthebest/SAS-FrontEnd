/**
  @module ember-data
*/

import "ember-data/-private/system/debug/debug-info";
import DebugAdapter from "ember-data/-private/system/debug/debug-adapter";

export default DebugAdapter;