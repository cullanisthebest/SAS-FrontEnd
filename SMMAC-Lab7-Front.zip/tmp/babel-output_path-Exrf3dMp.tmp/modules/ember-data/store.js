import Store from "ember-data/-private/system/store";

export default Store;